﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Drag_Racers
{
    public partial class Form1 : Form
    {

        SolidBrush pinkBrush = new SolidBrush(Color.Pink);
        Graphics carPaint = null;

        private MovingCar car;

        public Form1()
        {
            InitializeComponent();
            InitializeForm1();
        }

        private void InitializeForm1()
        {
            this.Size = new Size(500, 1000);
            this.Text = "Drag Racerz";

            int carHeight = 50;
            int carWidth = 35;
            int carX = 100;
            int carY = 100;

            float defaultSpeed = 10;
            float defaultyVel = (float)Math.Cos(defaultSpeed) * defaultSpeed;

            car = new MovingCar(carX, carY, carWidth, carHeight, true, defaultSpeed, 0, pinkBrush);
        }



        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                PaintCar();
                MessageBox.Show("Test");
            }
        }


        private void PaintCar()
        {
            carPaint = this.CreateGraphics();
            //        carPaint.FillRectangle(car.getDrawingbrushColor(), car.getCarposition());
            carPaint.FillRectangle(pinkBrush, 100, 850, 100, 100);
        }




        private void Form1_Load(object sender, EventArgs e)
        {

        }

    }
}
