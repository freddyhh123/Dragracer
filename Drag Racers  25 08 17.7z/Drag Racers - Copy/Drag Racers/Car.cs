﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;

namespace Drag_Racers
{
    
    class Car
    {
        protected bool visible;
        protected Rectangle carPosition;
        protected System.Drawing.Brush drawingbrushcolor;
        
        public Car(int x, int y, int width, int height, bool visible, Brush drawingbrushcolor)
        {
            this.visible = visible;
            carPosition = new Rectangle(x, y, width, height);
            this.drawingbrushcolor = drawingbrushcolor;
        }

        #region car func
        public bool Getvisible()
        {
            return visible;
        }

        public Rectangle getCarposition()
        {
            return carPosition;
        }

        public Brush getDrawingbrushColor()
        {
            return drawingbrushcolor;
        }

        public void setvisible (bool isvisible)
        {
            visible = isvisible;
        }

        public void SetRecPosition(Rectangle position)
        {
            carPosition = position;
        }

        public void setDrawingbrushcolor(Brush brushColor)
        {
            drawingbrushcolor = brushColor;
        }

        public void makevisible()
        {
            visible = true;
        }

        public void MakeInvisible()
        {
            visible = false;
        }
        #endregion

     
        }


        





    }








