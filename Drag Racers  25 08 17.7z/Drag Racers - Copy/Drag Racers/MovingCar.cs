﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
namespace Drag_Racers
{
    class MovingCar : Car
    {
        private float carSpeed;
      
        private float yVel;

        public MovingCar(int x, int y, int width, int height, bool visible, float carSpeed, float yVel, Brush drawingbrushcolor) : base(x, y, width, height, visible, drawingbrushcolor)
        {
            this.carSpeed = carSpeed;
            
            this.yVel = yVel;
        }

        public float getCarSpeed()
        {
            return carSpeed;
        }

        
        public float getyVel()
        {
            return yVel;
        }

        public void SetFltSpeed(float speed)
        {
            carSpeed = speed;
        }

     

        public void SetFltYVel(float yVel2)
        {
            yVel = yVel2;
        }

        

        public void ChangePosition(int x, int y)
        {
            carPosition.Location = new Point(x, y);
        }
        public void ChangePosition(int x)
        {
            carPosition.Location = new Point(x, carPosition.Y);
        }


    }


    
}
