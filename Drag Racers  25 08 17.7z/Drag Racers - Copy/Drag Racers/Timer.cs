﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Drag_Racers
{
    class Timer
    {
    public void InitializeTimer()
    {
        public int counter = 0;
        t.Interval = 750;
        t.enabled = true;
        timer1_Tick(null,null);

        t.Tick += new EventHandler(timer1_Tick);
    }



    }
}
